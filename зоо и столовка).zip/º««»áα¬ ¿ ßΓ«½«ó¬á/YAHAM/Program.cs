﻿using System;
using ZOO;
using static ZOO.Zoo;

class Program
{
    static void Main(string[] args)
    {
        Animal[] animals = new Animal[5];

        Penguin penguin = new Penguin("Ангелина", 5);
        Monkey monkey = new Monkey("Степа", 3);
        Kitty kitty = new Kitty("Максимочка", 2);
        Bee bee = new Bee("Ярослав", 10);
        Hedgehog hedgehog = new Hedgehog("Анастасися", 12);

        animals[0] = penguin;
        animals[1] = monkey;
        animals[2] = kitty;
        animals[3] = bee;
        animals[4] = hedgehog;

        foreach (Animal animal in animals)
        {
            Console.WriteLine(animal.MakeSound());
        }

        Console.WriteLine("Вам предстоит выбрать зверушку:\r\n" + "1. Ангелина\r\n" + "2. Степа\r\n" + "3. Максимочка\r\n" + "4. Ярослав\r\n" + "5. Анастасися\r\n");
        var choice = Convert.ToInt32(Console.ReadLine());

        if (choice >= 1 && choice <= 5)
        {
            Animal selectedAnimal = animals[choice - 1];
            Console.WriteLine($"Вы пошли вместе с {selectedAnimal.Name} ({selectedAnimal.Species}) в столовую.");

            Random random = new Random();
            IFoodProvider foodProvider = random.Next(2) == 0 ? (IFoodProvider)new GoodCook() : (IFoodProvider)new FancyCook();

            Console.WriteLine($"Поднявшись на 5 этаж, вы изрядко устали. Увидели, что сегодня {foodProvider.ProvideFood()}");

            if (foodProvider.IsEvil())
            {
                Console.WriteLine("Выберите действие:\r\n" + "1. Разгневаться\r\n" + "2. Промолчать\r\n");
                var actionChoice = Convert.ToInt32(Console.ReadLine());

                if (actionChoice == 1)
                {
                    Console.WriteLine("Разбить тарелку и получить за это по шапке...");
                }
                else if (actionChoice == 2)
                {
                    Console.WriteLine("Вы промолчали, и спокойно забираете свою порцию еды.");
                }
                else
                {
                    Console.WriteLine("Неправильный выбор!");
                }
            }
            else
            {
                Console.WriteLine("Вы решаете съесть приготовленную еду\r\n" + " Повариха желает вам приятного аппетита!\r\n");
            }
        }
        else
        {
            Console.WriteLine("Неправильный выбор!");
        }

        Console.ReadLine();
    }
}