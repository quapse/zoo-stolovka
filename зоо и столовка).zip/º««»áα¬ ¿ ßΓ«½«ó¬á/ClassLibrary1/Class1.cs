﻿namespace ZOO
{
    public interface IFoodProvider
    {
        string ProvideFood();
        bool IsEvil();
    }

    public class FancyCook : IFoodProvider
    {
        private readonly string[] menu = { "Рис с курицой", "Пельмени", "суп с тефтельками" };

        public string ProvideFood()
        {
            Random random = new Random();
            int foodChoice = random.Next(1, menu.Length + 1);

            if (foodChoice >= 1 && foodChoice <= menu.Length)
            {
                return menu[foodChoice - 1];
            }

            return "Неправильный выбор!";
        }

        public bool IsEvil()
        {
            return true;
        }
    }

    public class GoodCook : IFoodProvider
    {
        private readonly string[] menu = { "Макарошки с наггетсами", "Гречка с ежиками", "Борщ" };

        public string ProvideFood()
        {
            Random random = new Random();
            int foodChoice = random.Next(1, menu.Length + 1);

            if (foodChoice >= 1 && foodChoice <= menu.Length)
            {
                return menu[foodChoice - 1];
            }

            return "Неправильный выбор!";
        }

        public bool IsEvil()
        {
            return false;
        }
    }

    public class Zoo
    {
        public class Animal
        {
            public string Name;
            public int Age;
            public string Species;
            public string Sound;

            public Animal(string name, int age, string species, string sound)
            {
                Name = name;
                Age = age;
                Species = species;
                Sound = sound;
            }

            public virtual string MakeSound()
            {
                return $"{Name} {Species} издает звук: {Sound}";
            }
        }

        public class Penguin : Animal
        {
            public Penguin(string name, int age) : base(name, age, "Пингвин", "кхм")
            {
            }
        }

        public class Monkey : Animal
        {
            public Monkey(string name, int age) : base(name, age, "Обезьяна", "у-у-у")
            {
            }
        }

        public class Kitty : Animal
        {
            public Kitty(string name, int age) : base(name, age, "Котенок", "мяяяяв")
            {
            }
        }

        public class Bee : Animal
        {
            public Bee(string name, int age) : base(name, age, "Пчела", "Ж-ж-ж-ж")
            {
            }
        }

        public class Hedgehog : Animal
        {
            public Hedgehog(string name, int age) : base(name, age, "Ёжик", "Фыр-фыр")
            {
            }
        }
    }
}